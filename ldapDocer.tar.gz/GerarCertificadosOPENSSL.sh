#!/bin/bash

cd /etc/pki/tls/certs/

yum  install openssl make expect.x86_64  -y;

expect -c " 
spawn make server.key
expect \"Enter*\"
send  \"teste@123\r\"
expect \"Enter*\"
send  \"teste@123\r\"
spawn openssl rsa -in server.key -out server.key
expect \"Enter*\"
send  \"teste@123\r\"
spawn make server.crt
expect \"Country*\"
send \"BR\r\"
expect \"State*\"
send \"Rio Grande Do Norte\r\"
expect \"Locality*\"
send \"Natal\r\"
expect \"Organization*\"
send \"UFRN\r\"
expect \"Organizational*\"
send \"SINFO\r\"
expect \"Common*\"
send \"$HOSTNAME\r\"
expect \"Email*\"
send \"sinfo@info.ufrn.br\r\"
expect \"A*\"
send \"\r\"
expect \"An*\"
send \"\r\"
interact
"




