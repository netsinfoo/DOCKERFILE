o "Digite o ip ou nome do servidor ldap que deseja fazer o pam"
#read pam
pam="10.3.156.9"

if [ -e /etc/debian_version ];
then
        export DEBIAN_FRONTEND=noninteractive
	apt-get update;        
	apt-get -y install ldap-utils nslcd;

	BASE="ou=debian,ou=nslcd,dc=ufrn,dc=br";
	BINDDN="binddn cn=monitor,ou=admin,ou=nslcd,dc=ufrn,dc=br";
	BINDPW="bindpw maneo@2016";
	nsswitchPasswd="passwd:         compat ldap"
	nsswitchGroup="group:         compat ldap"
	nsswitchShadow="shadow:         compat ldap"


	
	sed -i "/uri ldap:/c uri ldap:\/\/$pam/"  /etc/nslcd.conf
	#sed -i "/base dc=example,dc=net/c base $BASE"  /etc/nslcd.conf
	sed -i "/base dc/c base $BASE"  /etc/nslcd.conf
	sed -i "/#binddn cn=annonymous,dc=example,dc=net/c $BINDDN"  /etc/nslcd.conf
	sed -i "/#bindpw secret/c $BINDPW"  /etc/nslcd.conf

	sed -i "/passwd:         compat/c $nsswitchPasswd"  /etc/nsswitch.conf
	sed -i "/group:          compat/c $nsswitchGroup"  /etc/nsswitch.conf
	sed -i "/shadow:         compat/c $nsswitchShadow"  /etc/nsswitch.conf

	#echo  "filter passwd (ou=$HOSTNAME)" >> /etc/nslcd.conf	
pam-auth-update
	
echo session required        pam_mkhomedir.so umask=0022 skel=/etc/skel >> /etc/pam.d/common-session
service nscd stop
service nslcd restart

else
        yum -y install openldap-clients nss-pam-ldapd;
        BASE="ou=centos,ou=nslcd,dc=ufrn,dc=br";

authconfig --enableldap --enableldapauth --ldapserver=$pam --ldapbasedn=$BASE --enablemkhomedir --update

binddn='binddn cn=monitor,ou=admin,ou=nslcd,dc=ufrn,dc=br'
sed -i "/binddn/c $binddn"  /etc/nslcd.conf

bindpw='bindpw maneo@2016'
sed -i "/bindpw secret/c $bindpw"  /etc/nslcd.conf
#echo  "filter passwd (ou=$HOSTNAME)" >> /etc/nslcd.conf

systemctl restart nslcd
fi


